<?php
// new texts
$_['text_myvar'] = 'This is the new field:';
?>