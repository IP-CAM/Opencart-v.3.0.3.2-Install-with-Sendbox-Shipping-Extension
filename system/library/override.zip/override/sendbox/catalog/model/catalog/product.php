<?php
class sendbox_ModelCatalogProduct extends ModelCatalogProduct{


}