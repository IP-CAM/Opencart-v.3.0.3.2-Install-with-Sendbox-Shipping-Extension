<?php
class sendbox_ControllerProductProduct extends ControllerProductProduct {

   
}
?>