$(document).ready(function(){
    alert('helo world');
    console.log('hello wolrd');
});